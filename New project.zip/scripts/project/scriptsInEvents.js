


const scriptsInEvents = {

		async EventSheet1_Event7(runtime, localVars)
		{
			
		}

};

self.C3.ScriptsInEvents = scriptsInEvents;

